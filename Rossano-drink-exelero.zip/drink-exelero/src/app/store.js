import { configureStore } from '@reduxjs/toolkit';
import searchIngredientReducer from '../features/search-ingredient/searchSlice';
import drinksByIngredientReducer from '../features/drinks/drinksByIngredient';
import commonReducer from '../features/common/reducers/commonReducer';

export default configureStore({
  reducer: {
    search: searchIngredientReducer,
    drinksByIngredient: drinksByIngredientReducer,
    common: commonReducer
  },
});
