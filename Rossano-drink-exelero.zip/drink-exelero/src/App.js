/** @jsx jsx */
import { jsx } from '@emotion/core';
import { SearchIngredient } from './features/search-ingredient/SearchIngredient';
import { TopBar } from './features/topbar/TopBar';
import { OrderModal } from './features/order/OrderModal';
import './App.css';
import { SelectDrinkModal } from './features/drinks/SelectDrinkModal';

const styles = {
  appContainer: {
    display: 'grid',
    gridTemplateRows: "70px 300px",
  }
}

function App() {
  return (
    <div css={styles.appContainer}>
      <TopBar />
      <SearchIngredient />
      <OrderModal />
      <SelectDrinkModal />
    </div>
  );
}

export default App;
