import { createSlice } from '@reduxjs/toolkit';
import { drinkByIngredient } from '../common/utilities/urls';


export const drinksByIngredient = createSlice({
    name: 'drinksByIngredient',
    initialState: {
        drinks: [],
        busy: false,
    },
    reducers: {
        fetchDrinks: (state) => {
            return Object.assign({}, state, {
                drinks: [],
                busy: true,
            })
        },
        fetchDrinksSuccess: (state, action) => {
            return Object.assign({}, state, {
                drinks: action.payload,
                busy: false,
            })
        },
        fetchDrinksError: (state) => {
            // Maybe throw an exception and show a toastr with the error
            return Object.assign({}, state, {
                drinks: [],
                busy: false,
            })
        },
    },
});

export const { fetchDrinks, fetchDrinksSuccess, fetchDrinksError } = drinksByIngredient.actions;

export const fetchDrinkByIngredientAsync = (ingredient) => dispatch => {
    dispatch(fetchDrinks());
    fetch(`${drinkByIngredient}${ingredient.strIngredient}`)
        .then(res => res.json())
        .then(
            (result) => {
                dispatch(fetchDrinksSuccess(result.drinks));
            },
            (error) => {
                fetchDrinksError();
            }
        )

};

export const selectDrinks = state => state.drinksByIngredient.drinks;
export const selectIsBydyFetchDrinksByIngredient = state => state.drinksByIngredient.busy;

export default drinksByIngredient.reducer;
