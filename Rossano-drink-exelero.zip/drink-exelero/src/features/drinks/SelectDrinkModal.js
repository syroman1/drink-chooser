import Modal from '@material-ui/core/Modal';
import { makeStyles } from '@material-ui/core/styles';
import React, { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { closeSelectDrinkModal, selectIsOpenSelectDrinkModal, selectSelectedIngredient, addDrinkToOrder } from '../common/reducers/commonReducer';
import { fetchDrinkByIngredientAsync, selectDrinks } from './drinksByIngredient';
import { selectIsBydyFetchDrinksByIngredient } from '../drinks/drinksByIngredient';
import { LinearProgress, Card, CardActionArea, CardContent, Typography, CardMedia } from '@material-ui/core';

function rand() {
    return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
    const top = 50 + rand();
    const left = 50 + rand();

    return {
        top: `${top}%`,
        left: `${left}%`,
        transform: `translate(-${top}%, -${left}%)`,
        width: '1300px',
        height: '1000px',
        overflow: 'auto'
    };
}

const useStyles = makeStyles((theme) => ({
    paper: {
        position: 'absolute',
        width: 800,
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 4, 3),
    },
    drinkMedia: {
        height: 410,
    },
    drinkContainer: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gridGap: '25px',
        gridRowGap: '25px'
    }
}));

export function SelectDrinkModal() {
    const classes = useStyles();

    const [modalStyle] = React.useState(getModalStyle);
    const open = useSelector(selectIsOpenSelectDrinkModal);
    const ingredient = useSelector(selectSelectedIngredient);
    const busyFetchDrink = useSelector(selectIsBydyFetchDrinksByIngredient);
    const drinks = useSelector(selectDrinks);
    const dispatch = useDispatch();

    const handleClose = useCallback(
        () => {
            dispatch(closeSelectDrinkModal())
        },
        [dispatch],
    );

    useEffect(() => {
        dispatch(fetchDrinkByIngredientAsync(ingredient));
        return () => {

        }
    }, [dispatch, ingredient]);


    const body = (
        <div style={modalStyle} className={classes.paper}>
            <h2>Select Drink</h2>
            {
                busyFetchDrink ?
                    <LinearProgress></LinearProgress> :
                    <div className={classes.drinkContainer}>
                        {drinks && drinks.map(drink => <Drink drink={drink} key={drink.idDrink} />)}
                    </div>
            }
        </div>
    );

    return (
        <div>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="simple-modal-title"
                aria-describedby="simple-modal-description"
            >
                {body}
            </Modal>
        </div>
    );
}

function Drink(props) {
    const { drink } = props;

    const dispatch = useDispatch();

    const handleClick = useCallback(
        () => {
            dispatch(addDrinkToOrder(drink));
        },
        [dispatch, drink],
    );

    const classes = useStyles();
    return (
        <Card className={classes.drink} onClick={handleClick}>
            <CardActionArea>
                <Typography gutterBottom variant="h5" component="h2">
                    {drink.strDrink}
                </Typography>
                <CardMedia
                    className={classes.drinkMedia}
                    image={drink.strDrinkThumb}
                    title={drink.strDrink}
                />
                <CardContent>

                </CardContent>
            </CardActionArea>
        </Card>
    );
}