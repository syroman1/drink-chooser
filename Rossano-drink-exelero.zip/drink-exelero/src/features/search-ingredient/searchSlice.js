import { createSlice } from '@reduxjs/toolkit';
import { ingredient } from '../common/utilities/urls';

export const searchSlice = createSlice({
    name: 'search',
    initialState: {
        ingredients: [],
        busy: false,
    },
    reducers: {
        fetchIngredient: (state) => {
            return Object.assign({}, state, {
                ingredients: [],
                busy: true,
            })
        },
        fetchIngredientSuccess: (state, action) => {
            return Object.assign({}, state, {
                ingredients: action.payload,
                busy: false,
            })
        },
        fetchIngredientkError: (state) => {
            return Object.assign({}, state, {
                ingredients: [],
                busy: false,
            })
        },
    },
});

export const { fetchIngredient, fetchIngredientSuccess, fetchIngredientkError } = searchSlice.actions;

export const fetchDataAsync = search => dispatch => {
    dispatch(fetchIngredient());
    fetch(`${ingredient}${search}`)
        .then(res => res.json())
        .then(
            (result) => {
                dispatch(fetchIngredientSuccess(result.ingredients));
            },
            (error) => {
                fetchIngredientkError();
            }
        )

};

export const selectIngredients = state => state.search.ingredients;
export const selectSearchIngredientBusy = state => state.search.busy;

export default searchSlice.reducer;
