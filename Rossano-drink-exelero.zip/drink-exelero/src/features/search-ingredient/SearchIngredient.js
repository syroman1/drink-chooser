import { Card, CardActionArea, CardContent, LinearProgress, makeStyles, Typography } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import React, { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useDebouncedCallback } from 'use-debounce';

import { fetchDataAsync, selectIngredients, selectSearchIngredientBusy } from './searchSlice';
import { openSelectDrinkModal } from '../common/reducers/commonReducer';

const useStyles = makeStyles({
    container: {
        display: 'grid',
        gridAutoFlow: 'row',
        gridGap: 15
    },
    title: {
        display: 'grid',
        justifyContent: 'center',
        gridAutoFlow: 'row'
    },
    ingredients: {
        display: 'grid',
        gridAutoFlow: 'column',
        gridGap: 10,
        padding: 20
    },
    root: {
        padding: 40,
        maxWidth: 345,
    },
    media: {
        height: 140,
    },
});

export function SearchIngredient() {
    const classes = useStyles();

    const ingredients = useSelector(selectIngredients);
    const busy = useSelector(selectSearchIngredientBusy);
    const dispatch = useDispatch();

    const [
        handleDebouncedChange,
        cancelDebounce,
        pendingDebounce,
    ] = useDebouncedCallback((search) => {
        if (!!search) {
            dispatch(fetchDataAsync(search));
        }
    }, 350);

    const handleSearch = useCallback(
        (event) => {
            const search = event.currentTarget.value;
            handleDebouncedChange(search);
        },
        [handleDebouncedChange],
    );

    useEffect(() => {
        return () => cancelDebounce();
    }, [cancelDebounce]);

    return (
        <div className={classes.container}>
            <div className={classes.title}>
                <Typography>
                    Please search your ingredient
            </Typography>
                <TextField id="standard-basic" label="Ingredient" onChange={handleSearch}
                    onBlur={pendingDebounce} />
            </div>
            <div className={classes.ingredients}>
                {busy ? <LinearProgress></LinearProgress> : ingredients && ingredients.map(ingredient =>
                    <Ingredient ingredient={ingredient} key={ingredient.idIngredient}></Ingredient>)}
            </div>
        </div>
    );
}

function Ingredient(props) {
    const { ingredient } = props;

    const truncateString = (string, max) => {
        if (!!string) {
            if (string.length > max) {
                return `${string.substring(0, max)}...`;
            }
            return string;
        }
    }

    const dispatch = useDispatch();

    const handleClick = useCallback(
        (_) => {
            dispatch(openSelectDrinkModal(ingredient));
        },
        [dispatch, ingredient],
    );

    const classes = useStyles();
    return (
        <Card className={classes.root} onClick={handleClick}>
            <CardActionArea>
                <CardContent>
                    <Typography gutterBottom variant="h5" component="h2">
                        {ingredient.strIngredient}
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p">
                        {truncateString(ingredient.strDescription, 200)}
                    </Typography>
                </CardContent>
            </CardActionArea>
        </Card>
    );
}
