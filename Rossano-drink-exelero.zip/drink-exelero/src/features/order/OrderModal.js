import Modal from '@material-ui/core/Modal';
import { makeStyles } from '@material-ui/core/styles';
import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { closeOrderModal, selectIsOpenOrderModal, selectOrder } from '../common/reducers/commonReducer';
import { Card, CardContent, Typography, CardMedia } from '@material-ui/core';

function rand() {
    return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
    const top = 50 + rand();
    const left = 50 + rand();

    return {
        top: `${top}%`,
        left: `${left}%`,
        transform: `translate(-${top}%, -${left}%)`,
        width: '1300px',
        height: '1000px',
        overflow: 'auto'
    };
}

const useStyles = makeStyles((theme) => ({
    paper: {
        position: 'absolute',
        width: 200,
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 4, 3),
    },
    details: {
        display: 'flex',
        flexDirection: 'column',
    },
    drinkMedia: {
        height: 200,
    },
    root: {
        display: 'grid',
        gridTemplateColumns: '1fr 2fr',
        gridRowGap: '20px'
    },
    dataOrder: {
        display: 'grid',
        gridTemplateRows: '1fr 1fr',
        gridGap: '10px'
    },
    order: {
        display: 'grid',
        gridTemplateRows: '1fr 1fr',
        gridGap: '10px'
    }
}));

export function OrderModal() {
    const classes = useStyles();

    const [modalStyle] = React.useState(getModalStyle);
    const open = useSelector(selectIsOpenOrderModal);
    const order = useSelector(selectOrder);
    const dispatch = useDispatch();

    const handleClose = useCallback(
        () => {
            dispatch(closeOrderModal())
        },
        [dispatch],
    );

    const body = (
        <div style={modalStyle} className={classes.paper}>
            <h2>Order</h2>
            <div className={classes.order}>
                {
                    order && order.map(o => <Order order={o} key={o.drink.idDrink} />)
                }
            </div>
        </div>
    );

    return (
        <div>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="simple-modal-title"
                aria-describedby="simple-modal-description"
            >
                {body}
            </Modal>
        </div>
    );
}

function Order(props) {
    const { order } = props;

    const classes = useStyles();

    return (
        <Card className={classes.root}>
            <CardMedia
                className={classes.drinkMedia}
                image={order.drink.strDrinkThumb}
                title={order.drink.strDrink}
            />
            <div className={classes.dataOrder}>
                <CardContent className={classes.content}>
                    <Typography component="h5" variant="h5">
                        {order.drink.strDrink}
                    </Typography>
                </CardContent>
                <CardContent className={classes.content}>
                    <Typography component="h5" variant="h5">
                        Quantity : {order.quantity}
                    </Typography>
                </CardContent>
            </div>
        </Card>
    );
}