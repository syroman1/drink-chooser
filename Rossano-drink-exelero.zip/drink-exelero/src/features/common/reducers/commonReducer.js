import { createSlice } from '@reduxjs/toolkit';
import produce from "immer";

export const common = createSlice({
    name: 'common',
    initialState: {
        ui: {
            orderModalOpen: false,
            selectDrinkModalOpen: false,
        },
        selectedIngredient: '',
        order: [] //{ drink: {}, quantity: 0 }
    },
    reducers: {
        openOrderModal: (state) => {
            return Object.assign({}, state, {
                ui: {
                    orderModalOpen: true
                }
            })
        },
        closeOrderModal: (state) => {
            return Object.assign({}, state, {
                ui: {
                    orderModalOpen: false
                }
            })
        },
        openSelectDrinkModal: (state, action) => {
            return Object.assign({}, state, {
                ui: {
                    selectDrinkModalOpen: true
                },
                selectedIngredient: action.payload
            })
        },
        closeSelectDrinkModal: (state) => {
            return Object.assign({}, state, {
                ui: {
                    selectDrinkModalOpen: false
                }
            })
        },
        addDrinkToOrder: (state, action) => {
            const nextState = produce(state, draftState => {
                const drinkIndex = draftState.order.findIndex(d => d.drink.idDrink === action.payload.idDrink);
                if (drinkIndex !== -1) {
                    const toIncrease = draftState.order[drinkIndex];
                    toIncrease.quantity += 1;
                    draftState.order[drinkIndex] = toIncrease;
                }
                else {
                    draftState.order.push({ drink: action.payload, quantity: 1 });
                }

                draftState.order.sort((a, b) => (a.quantity > b.quantity) ? -1 : 1)
            });

            return nextState;
        },

    },
});

export const {
    openOrderModal,
    closeOrderModal,
    openSelectDrinkModal,
    closeSelectDrinkModal,
    addDrinkToOrder
} = common.actions;

export const selectIsOpenOrderModal = state => state.common.ui.orderModalOpen;
export const selectIsOpenSelectDrinkModal = state => state.common.ui.selectDrinkModalOpen;
export const selectSelectedIngredient = state => state.common.selectedIngredient;
export const selectOrder = state => state.common.order;
export const selectNumberOfDrink = state => state.common.order.reduce((r, d) => r + d.quantity, 0);

export default common.reducer;
