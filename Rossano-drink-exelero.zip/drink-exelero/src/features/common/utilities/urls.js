export const drinkByIngredient = 'https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=';
export const ingredient = 'https://www.thecocktaildb.com/api/json/v1/1/search.php?i=';