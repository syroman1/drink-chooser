import { makeStyles, Typography } from '@material-ui/core';
import Badge from '@material-ui/core/Badge';
import indigo from '@material-ui/core/colors/indigo';
import IconButton from '@material-ui/core/IconButton';
import { createStyles, withStyles } from '@material-ui/core/styles';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { openOrderModal } from '../common/reducers/commonReducer';
import { selectNumberOfDrink } from '../common/reducers/commonReducer';


const useStyles = makeStyles({
    container: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        alignContent: 'center',
        zIndex: 1,
        width: '100%',
        height: '100%',
        backgroundColor: indigo[500],
    },
    cart: {
        justifySelf: 'end',
    }
});


const StyledBadge = withStyles((theme) =>
    createStyles({
        badge: {
            right: -3,
            top: 13,
            border: `2px solid ${theme.palette.background.paper}`,
            padding: '0 4px',
        },
    }),
)(Badge);

export function TopBar() {
    const classes = useStyles();
    const dispatch = useDispatch();

    const numberOfDrink = useSelector(selectNumberOfDrink);


    const handleOpenOrderModal = useCallback(
        () => {
            dispatch(openOrderModal())
        },
        [dispatch],
    );

    return (
        <div className={classes.container}>
            <Typography gutterBottom variant="h5" component="h2">Drink chooser</Typography>
            <div className={classes.cart}>
                <IconButton aria-label="cart" onClick={handleOpenOrderModal}>
                    {
                        <StyledBadge badgeContent={numberOfDrink} color="secondary">
                            <ShoppingCartIcon />
                        </StyledBadge>

                    }
                </IconButton>
            </div>
        </div>
    );
}

